import bpy
import json
import base64
import os

from bpy_extras.io_utils import ExportHelper
from bpy.props import StringProperty
from bpy.types import Operator


# ============================================================
# Helpers
# ============================================================

def clamp_byte(value):
    return int(max(0.0, min(1.0, value)) * 255)


def get_active_uv_layer(mesh):
    if hasattr(mesh, "uv_layers"):
        return mesh.uv_layers.active

    return None


def get_vertex_color(mesh, loop_index):
    # Blender 3.x / 4.x / 5.x color attributes
    if hasattr(mesh, "color_attributes"):
        attributes = mesh.color_attributes

        if attributes:
            attribute = attributes.active

            if attribute:
                try:
                    color = attribute.data[loop_index].color

                    return [
                        clamp_byte(color[0]),
                        clamp_byte(color[1]),
                        clamp_byte(color[2]),
                        clamp_byte(color[3])
                    ]

                except Exception:
                    pass

    # Older Blender versions
    if hasattr(mesh, "vertex_colors"):
        layers = mesh.vertex_colors

        if layers:
            layer = layers.active

            if layer:
                try:
                    color = layer.data[loop_index].color

                    return [
                        clamp_byte(color[0]),
                        clamp_byte(color[1]),
                        clamp_byte(color[2]),
                        clamp_byte(color[3])
                    ]

                except Exception:
                    pass

    return [255, 255, 255, 255]


# ============================================================
# Texture Export
# ============================================================

def find_material_image(material):
    """
    Find an image connected to the Principled BSDF Base Color.

    Returns:
        bpy.types.Image or None
    """

    if material is None:
        return None

    if not material.use_nodes:
        return None

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    principled = None

    # Find Principled BSDF
    for node in nodes:
        if node.type == "BSDF_PRINCIPLED":
            principled = node
            break

    if principled is None:
        return None

    base_color_input = principled.inputs.get("Base Color")

    if base_color_input is None:
        return None

    # Look for a linked Image Texture
    for link in links:
        if link.to_node == principled:
            if link.to_socket == base_color_input:
                source = link.from_node

                if source.type == "TEX_IMAGE":
                    return source.image

    return None


def image_to_png_base64(image):
    """
    Convert a Blender image into PNG bytes and Base64.

    The original Blender image is not modified.
    """

    if image is None:
        return ""

    # Save the image to a temporary PNG file.
    temp_dir = bpy.app.tempdir

    if not temp_dir:
        temp_dir = os.path.dirname(bpy.data.filepath)

    if not temp_dir:
        temp_dir = "."

    temp_path = os.path.join(
        temp_dir,
        "timworks_texture_export.png"
    )

    old_filepath = image.filepath_raw
    old_format = image.file_format

    try:
        image.filepath_raw = temp_path
        image.file_format = "PNG"

        image.save()

        with open(temp_path, "rb") as file:
            data = file.read()

        return base64.b64encode(data).decode("ascii")

    finally:
        image.filepath_raw = old_filepath
        image.file_format = old_format

        try:
            if os.path.exists(temp_path):
                os.remove(temp_path)
        except Exception:
            pass


# ============================================================
# Materials
# ============================================================

def export_materials(objects):
    materials = []
    material_indices = {}

    for obj in objects:
        for slot in obj.material_slots:

            material = slot.material

            if material is None:
                continue

            name = material.name

            if name in material_indices:
                continue

            index = len(materials)

            material_indices[name] = index

            texture = {
                "embedded": False,
                "mime": "",
                "data": ""
            }

            # Try to find a Base Color image
            image = find_material_image(material)

            if image is not None:
                try:
                    base64_data = image_to_png_base64(image)

                    if base64_data:
                        texture["embedded"] = True
                        texture["mime"] = "image/png"
                        texture["data"] = base64_data

                except Exception as error:
                    print(
                        "[TimWorks] Failed to export texture:",
                        error
                    )

            materials.append({
                "name": name,
                "texture": texture
            })

    return materials, material_indices


# ============================================================
# Mesh Export
# ============================================================

def export_mesh(objects, material_indices, depsgraph):
    vertices = []
    indices = []
    surfaces = []

    vertex_map = {}

    # Each surface gets:
    #
    # {
    #     "firstIndex": ...,
    #     "material": ...
    # }
    #
    # We create surfaces as triangles are added, then calculate
    # indexCount from the final index position.

    surface_data = {}

    for obj in objects:

        if obj.type != "MESH":
            continue

        # Get the evaluated object so modifiers can be included.
        evaluated_obj = obj.evaluated_get(depsgraph)

        mesh = evaluated_obj.to_mesh()

        if mesh is None:
            continue

        try:
            # Bake the object's world transform into the vertex positions.
            world_matrix = evaluated_obj.matrix_world

            # Make sure loop triangles and normals are available.
            mesh.calc_loop_triangles()
            mesh.calc_normals_split()

            uv_layer = get_active_uv_layer(mesh)

            # Keep track of surfaces for this object.
            object_surfaces = {}

            for triangle in mesh.loop_triangles:

                blender_material_index = triangle.material_index

                exported_material = -1

                if (
                    blender_material_index >= 0
                    and
                    blender_material_index < len(
                        evaluated_obj.material_slots
                    )
                ):
                    slot = evaluated_obj.material_slots[
                        blender_material_index
                    ]

                    if slot.material:
                        exported_material = material_indices.get(
                            slot.material.name,
                            -1
                        )

                surface_key = (
                    evaluated_obj.name,
                    exported_material
                )

                if surface_key not in object_surfaces:

                    object_surfaces[surface_key] = {
                        "firstIndex": len(indices),
                        "material": exported_material
                    }

                for loop_index in triangle.loops:

                    loop = mesh.loops[loop_index]

                    blender_vertex = mesh.vertices[
                        loop.vertex_index
                    ]

                    # ------------------------------------------------
                    # Position
                    # ------------------------------------------------

                    position = (
                        world_matrix @ blender_vertex.co
                    )

                    # ------------------------------------------------
                    # Normal
                    # ------------------------------------------------

                    normal = loop.normal

                    # Transform normal correctly.
                    normal = (
                        world_matrix.to_3x3()
                        .inverted()
                        .transposed()
                        @ normal
                    )

                    normal.normalize()

                    # ------------------------------------------------
                    # UV
                    # ------------------------------------------------

                    if uv_layer:
                        uv = uv_layer.data[
                            loop_index
                        ].uv

                        texcoord = [
                            float(uv.x),
                            float(uv.y)
                        ]

                    else:
                        texcoord = [0.0, 0.0]

                    # ------------------------------------------------
                    # Vertex color
                    # ------------------------------------------------

                    color = get_vertex_color(
                        mesh,
                        loop_index
                    )

                    # ------------------------------------------------
                    # Vertex deduplication
                    # ------------------------------------------------

                    key = (
                        loop.vertex_index,

                        round(position.x, 7),
                        round(position.y, 7),
                        round(position.z, 7),

                        round(normal.x, 7),
                        round(normal.y, 7),
                        round(normal.z, 7),

                        round(texcoord[0], 7),
                        round(texcoord[1], 7),

                        tuple(color)
                    )

                    if key not in vertex_map:

                        vertex_index = len(vertices)

                        vertex_map[key] = vertex_index

                        vertices.append({
                            "position": [
                                float(position.x),
                                float(position.y),
                                float(position.z)
                            ],

                            "normal": [
                                float(normal.x),
                                float(normal.y),
                                float(normal.z)
                            ],

                            "color": color,

                            "texcoord": texcoord,

                            "boneIds": [
                                0,
                                0,
                                0,
                                0
                            ],

                            "weights": [
                                1.0,
                                0.0,
                                0.0,
                                0.0
                            ]
                        })

                    indices.append(
                        vertex_map[key]
                    )

            # --------------------------------------------------------
            # Finish surfaces for this object
            # --------------------------------------------------------

            for surface in object_surfaces.values():

                first_index = surface["firstIndex"]

                index_count = (
                    len(indices)
                    - first_index
                )

                surfaces.append({
                    "firstIndex": first_index,
                    "indexCount": index_count,
                    "material": surface["material"],
                    "shading": "Smooth"
                })

        finally:
            evaluated_obj.to_mesh_clear()

    return {
        "vertices": vertices,
        "indices": indices,
        "bones": [],
        "surfaces": surfaces
    }


# ============================================================
# Model Creation
# ============================================================

def create_tw_model(context):

    objects = [
        obj
        for obj in context.selected_objects
        if obj.type == "MESH"
    ]

    if not objects:
        raise RuntimeError(
            "No mesh objects are selected."
        )

    depsgraph = context.evaluated_depsgraph_get()

    materials, material_indices = export_materials(
        objects
    )

    frame = export_mesh(
        objects,
        material_indices,
        depsgraph
    )

    return {
        "version": 0.1,

        "materials": materials,

        "idleFrame": frame,

        "collision": {
            "vertices": [],
            "indices": [],
            "surfaces": []
        },

        "frames": [],

        "animations": []
    }


# ============================================================
# Export Operator
# ============================================================

class TIMWORKS_OT_export(
    Operator,
    ExportHelper
):

    bl_idname = "export_scene.timworks_model"

    bl_label = "Export TimWorks Model"

    bl_options = {"PRESET"}

    filename_ext = ".tw_mdl"

    filter_glob: StringProperty(
        default="*.tw_mdl",
        options={"HIDDEN"}
    )

    def execute(self, context):

        try:

            model = create_tw_model(
                context
            )

            with open(
                self.filepath,
                "w",
                encoding="utf-8"
            ) as file:

                json.dump(
                    model,
                    file,
                    indent=4
                )

            self.report(
                {"INFO"},
                "TimWorks model exported successfully"
            )

            return {"FINISHED"}

        except Exception as error:

            self.report(
                {"ERROR"},
                str(error)
            )

            return {"CANCELLED"}


# ============================================================
# Registration
# ============================================================

classes = (
    TIMWORKS_OT_export,
)


def register():

    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)