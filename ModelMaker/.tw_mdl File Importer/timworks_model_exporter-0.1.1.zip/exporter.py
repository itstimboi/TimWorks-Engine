import bpy
import json

from bpy_extras.io_utils import ExportHelper

from bpy.props import StringProperty

from bpy.types import Operator


# ============================================================
# Helpers
# ============================================================

def get_active_uv_layer(mesh):
    if hasattr(mesh, "uv_layers"):
        return mesh.uv_layers.active

    return None


def get_vertex_color(mesh, loop_index):
    # Blender 3.x / 4.x / 5.x
    if hasattr(mesh, "color_attributes"):

        attributes = mesh.color_attributes

        if attributes:

            attribute = attributes.active

            if attribute:

                try:

                    color = attribute.data[
                        loop_index
                    ].color

                    return [
                        int(
                            max(
                                0.0,
                                min(1.0, color[0])
                            ) * 255
                        ),

                        int(
                            max(
                                0.0,
                                min(1.0, color[1])
                            ) * 255
                        ),

                        int(
                            max(
                                0.0,
                                min(1.0, color[2])
                            ) * 255
                        ),

                        int(
                            max(
                                0.0,
                                min(1.0, color[3])
                            ) * 255
                        )
                    ]

                except Exception:
                    pass

    # Older Blender
    if hasattr(mesh, "vertex_colors"):

        layers = mesh.vertex_colors

        if layers:

            layer = layers.active

            if layer:

                try:

                    color = layer.data[
                        loop_index
                    ].color

                    return [
                        int(
                            max(
                                0.0,
                                min(1.0, color[0])
                            ) * 255
                        ),

                        int(
                            max(
                                0.0,
                                min(1.0, color[1])
                            ) * 255
                        ),

                        int(
                            max(
                                0.0,
                                min(1.0, color[2])
                            ) * 255
                        ),

                        int(
                            max(
                                0.0,
                                min(1.0, color[3])
                            ) * 255
                        )
                    ]

                except Exception:
                    pass

    return [255, 255, 255, 255]


# ============================================================
# Materials
# ============================================================

def export_materials(objects):

    materials = []

    material_indices = {}

    for obj in objects:

        for slot in obj.material_slots:

            material = slot.material

            if material is None:
                continue

            name = material.name

            if name in material_indices:
                continue

            index = len(materials)

            material_indices[name] = index

            materials.append({
                "name": name,

                "texture": {
                    "embedded": False,
                    "mime": "",
                    "data": ""
                }
            })

    return materials, material_indices


# ============================================================
# Mesh
# ============================================================

def export_mesh(
    objects,
    material_indices
):

    vertices = []
    indices = []
    surfaces = []

    vertex_map = {}

    # --------------------------------------------------------
    # Each object
    # --------------------------------------------------------

    for obj in objects:

        if obj.type != "MESH":
            continue

        mesh = obj.data

        # Apply evaluated mesh data later.
        # For v0.1 we export the actual mesh.
        mesh.calc_loop_triangles()

        uv_layer = get_active_uv_layer(mesh)

        surface_starts = {}

        # ----------------------------------------------------
        # Triangles
        # ----------------------------------------------------

        for triangle in mesh.loop_triangles:

            blender_material_index = (
                triangle.material_index
            )

            exported_material = -1

            if (
                blender_material_index >= 0
                and
                blender_material_index <
                len(obj.material_slots)
            ):

                slot = obj.material_slots[
                    blender_material_index
                ]

                if slot.material:

                    exported_material = (
                        material_indices.get(
                            slot.material.name,
                            -1
                        )
                    )

            surface_key = (
                obj.name,
                exported_material
            )

            if surface_key not in surface_starts:

                surface_starts[surface_key] = {
                    "firstIndex": len(indices),
                    "material": exported_material
                }

            # ------------------------------------------------
            # Triangle vertices
            # ------------------------------------------------

            for loop_index in triangle.loops:

                loop = mesh.loops[
                    loop_index
                ]

                blender_vertex = mesh.vertices[
                    loop.vertex_index
                ]

                position = blender_vertex.co

                normal = loop.normal

                # UV
                if uv_layer:

                    uv = uv_layer.data[
                        loop_index
                    ].uv

                    texcoord = [
                        float(uv.x),
                        float(uv.y)
                    ]

                else:

                    texcoord = [
                        0.0,
                        0.0
                    ]

                # Color
                color = get_vertex_color(
                    mesh,
                    loop_index
                )

                # ------------------------------------------------
                # Vertex deduplication key
                # ------------------------------------------------

                key = (
                    loop.vertex_index,

                    round(position.x, 7),
                    round(position.y, 7),
                    round(position.z, 7),

                    round(normal.x, 7),
                    round(normal.y, 7),
                    round(normal.z, 7),

                    round(texcoord[0], 7),
                    round(texcoord[1], 7),

                    tuple(color)
                )

                if key not in vertex_map:

                    vertex_index = len(vertices)

                    vertex_map[key] = vertex_index

                    vertices.append({
                        "position": [
                            float(position.x),
                            float(position.y),
                            float(position.z)
                        ],

                        "normal": [
                            float(normal.x),
                            float(normal.y),
                            float(normal.z)
                        ],

                        "color": color,

                        "texcoord": texcoord,

                        "boneIds": [
                            0,
                            0,
                            0,
                            0
                        ],

                        "weights": [
                            1.0,
                            0.0,
                            0.0,
                            0.0
                        ]
                    })

                indices.append(
                    vertex_map[key]
                )

        # ----------------------------------------------------
        # Surfaces
        # ----------------------------------------------------

        for surface in surface_starts.values():

            first_index = surface[
                "firstIndex"
            ]

            surfaces.append({
                "firstIndex": first_index,

                "indexCount":
                    len(indices) - first_index,

                "material":
                    surface["material"],

                "shading": "Smooth"
            })

    return {
        "vertices": vertices,
        "indices": indices,
        "bones": [],
        "surfaces": surfaces
    }


# ============================================================
# TW Model
# ============================================================

def create_tw_model(context):

    objects = [
        obj
        for obj in context.selected_objects
        if obj.type == "MESH"
    ]

    if not objects:

        raise RuntimeError(
            "No mesh objects are selected."
        )

    materials, material_indices = (
        export_materials(objects)
    )

    frame = export_mesh(
        objects,
        material_indices
    )

    return {
        "version": 0.1,

        "materials": materials,

        "idleFrame": frame,

        "collision": {
            "vertices": [],
            "indices": [],
            "surfaces": []
        },

        "frames": [],

        "animations": []
    }


# ============================================================
# Export Operator
# ============================================================

class TIMWORKS_OT_export(
    Operator,
    ExportHelper
):

    bl_idname = "export_scene.timworks_model"

    bl_label = "Export TimWorks Model"

    bl_options = {"PRESET"}

    filename_ext = ".tw_mdl"

    filter_glob: StringProperty(
        default="*.tw_mdl",
        options={"HIDDEN"}
    )

    def execute(self, context):

        try:

            model = create_tw_model(
                context
            )

            with open(
                self.filepath,
                "w",
                encoding="utf-8"
            ) as file:

                json.dump(
                    model,
                    file,
                    indent=4
                )

            self.report(
                {"INFO"},
                "TimWorks model exported successfully"
            )

            return {"FINISHED"}

        except Exception as error:

            self.report(
                {"ERROR"},
                str(error)
            )

            return {"CANCELLED"}


# ============================================================
# Registration
# ============================================================

classes = (
    TIMWORKS_OT_export,
)


def register():

    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)