bl_info = {
    "name": "TimWorks Model Exporter",
    "author": "Tim Boi",
    "version": (0, 1, 0),
    "blender": (2, 80, 0),
    "location": "File > Export > TimWorks Model (.tw_mdl)",
    "description": "Exports Blender models to the TimWorks .tw_mdl format",
    "category": "Import-Export",
}


import bpy

from . import exporter


def menu_func_export(self, context):
    self.layout.operator(
        exporter.TIMWORKS_OT_export.bl_idname,
        text="TimWorks Model (.tw_mdl)"
    )


def register():
    exporter.register()

    bpy.types.TOPBAR_MT_file_export.append(
        menu_func_export
    )


def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(
        menu_func_export
    )

    exporter.unregister()


if __name__ == "__main__":
    register()